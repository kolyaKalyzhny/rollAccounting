package domain.exceptions

class GTINValidationException(message: String) : IllegalArgumentException(message)
