package domain.exceptions

class ScannerServiceException(message: String) : Exception(message)
