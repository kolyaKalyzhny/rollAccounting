package domain.models

data class Roll(
    val barcode: String
)
