package domain.models

data class Pallet(
    val barcode: String
)
