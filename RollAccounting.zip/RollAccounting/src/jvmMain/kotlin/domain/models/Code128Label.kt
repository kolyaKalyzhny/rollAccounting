package domain.models

data class Code128Label(
    val value: String
)
