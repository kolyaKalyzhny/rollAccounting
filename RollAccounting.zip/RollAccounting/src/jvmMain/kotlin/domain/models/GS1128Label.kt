package domain.models

data class GS1128Label(
    val value: String
)
