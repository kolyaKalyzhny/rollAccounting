package domain.interfaces

interface TestRepository {
    fun testFunction()
}